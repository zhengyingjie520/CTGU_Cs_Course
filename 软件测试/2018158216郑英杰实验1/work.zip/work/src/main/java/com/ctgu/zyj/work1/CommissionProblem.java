package com.ctgu.zyj.work1;

public class CommissionProblem {

//    public Integer lockCounter = 0;
//    public Integer stockCounter = 0;
//    public Integer barrelCounter = 0;

    //输入数据处理部分
    public Integer[] inputDate(Integer[][] nums){
        Integer[] sum = {0,0,0};
        for (int i = 0;i<nums.length;i++){
            sum[0] += nums[i][0];
            sum[1] += nums[i][1];
            sum[2] += nums[i][2];
        }
        return sum;
    }

    public boolean checkDate(Integer[] sum){
        if (sum[0] <= 70 && sum[0]>=1 && sum[1]<=80 && sum[1]>=1 && sum[2]<=90 &&sum[2]>=1){
            return true;
        }else {
            return false;
        }
    }

    //销售额的统计计算部分,lock:45元，stock:30美元，barrel:25美元
    public String sumCommission(Integer[][] nums){
        Integer[] sum = inputDate(nums);
        double commission = 0;
        if (checkDate(sum)){
            double money = 1.0*(sum[0]*45+sum[1]*30+sum[2]*25);
//            System.out.println(money);
            if (money>1800){
                commission = (money - 1800)*0.2 + 800*0.15 + 1000*0.1;
            }else if (money>1000){
                commission = (money - 1000)*0.15+1000*0.1;
            }else {
                commission = money*0.1;
            }
            return "佣金为："+commission+"美元";
        }else{
            return "输入数据不合理！";
        }
    }

//    public static void main(String[] args) {
//        System.out.println(new CommissionProblem().sumCommission(new Integer[][]{{5,20,30},{20,30,40}}));
//    }
}
