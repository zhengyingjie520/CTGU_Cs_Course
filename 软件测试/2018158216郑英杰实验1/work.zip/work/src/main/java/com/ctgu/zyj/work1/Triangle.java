package com.ctgu.zyj.work1;

public class Triangle {

    //判断输入object是否为整数
    public static boolean isInteger(Object object){
        if (object instanceof Integer){
            return true;
        }else {
            return false;
        }
    }

    //判断三角形两边之和是否大于第三边
    public boolean judgeTriangle(int a,int b,int c){
        if (a+b>c&&b+c>a&&a+c>b){
            return true;
        }else {
            return false;
        }
    }

    //判断是否为等腰三角形
    public boolean strightLine(int a,int b,int c){
        if ((a==b&&b!=c)||(b==c&&c!=a)||(a==c&&c!=b)){
            return true;
        }else {
            return false;
        }
    }

    //判断输出
    public String isTriangle(Object... objects){
        //2.判断是否为3个数
        int len = objects.length;
        if (len!=3) return "输入错误";
        //1.判断object是否为整数
        for (Object object:objects){
                if (!isInteger(object)){
                    return "输入错误";
                }
        }
        //1，3.判断所有边长是否都大于等于1，小于等于100、
        String[] sides = new String[3];
        for (int i = 0;i<objects.length;i++){
             sides[i] = objects[i].toString();
             Integer temp = Integer.valueOf(sides[i]);
            if ((temp < 1 || temp > 100)){
                return "输入错误";
            }
        }
        int a = Integer.valueOf(sides[0]);
        int b = Integer.valueOf(sides[1]);
        int c = Integer.valueOf(sides[2]);
        if (!judgeTriangle(a,b,c)){
            return "非三角形";
        }
        if (a == b && b ==c){
            return "等边三角形";
        }
        if (strightLine(a,b,c)){
            return "等腰三角形";
        }
        return "一般三角形";
    }
}
