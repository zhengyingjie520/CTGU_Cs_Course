package com.ctgu.zyj.work1;

public class NextDate {

    public String nextDate(String line){
        //处理字符串
        line = line.replace('年',',');
        line = line.replace('月',',');
        line = line.replace('日',',');
        String[] str = line.split(",");
        Integer year = Integer.valueOf(str[0]);
        Integer month = Integer.valueOf(str[1]);
        Integer today = Integer.valueOf(str[2]);
        if (today==31){
            if (month == 12){
                if (year<1900||year>=2049){
                    return "日期输入错误";
                }
                month = 1;
                year = year + 1;
            }else if (month>12){
                return "日期输入错误";
            }else{
                month = month + 1;
            }
            today = 1;
        }else if (today>31){
            return "日期输入错误";
        }
        else {
            if (month > 12){
                return "日期输入错误";
            }else {
                today = today + 1;
            }
        }
        return year+"年"+month+"月"+today+"日";
    }
//    public static void main(String[] args) {
//        NextDate nextDate = new NextDate();
//        System.out.println(nextDate.nextDate("2051年12月31日"));
//    }
}
