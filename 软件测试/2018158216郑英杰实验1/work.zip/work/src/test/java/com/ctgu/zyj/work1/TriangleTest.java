package com.ctgu.zyj.work1;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(Parameterized.class)
public class TriangleTest {
    Triangle triangle = new Triangle();

    public String expected;
    public Object[] sides = null;

    public TriangleTest(String expected,Object[] sides){
        this.expected = expected;
        this.sides = sides;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> date() {
        return Arrays.asList(new Object[][]{
                {"输入错误", new Object[]{2.5,3,5}},//非整数测试
                {"输入错误", new Object[]{3,4,5,6}},//输入参数大于3
                {"输入错误", new Object[]{3,4}},//输入参数小于3
                {"输入错误", new Object[]{-3,2,4}},//参数小于1
                {"输入错误", new Object[]{100,105,60}},//参数大于100
                {"非三角形", new Object[]{3,2,5}},//两边之和等于第三边
                {"非三角形", new Object[]{2,2,5}},//两边之和小于第三边
                {"等边三角形", new Object[]{3,3,3}},
                {"等腰三角形", new Object[]{4,4,5}},
                {"一般三角形", new Object[]{3,4,5}}
        }
        );
    }

    @Test
    public void isTriangle() {
        assertEquals(expected,triangle.isTriangle(sides));
    }
}