package com.ctgu.zyj.work1;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.*;

@RunWith(Parameterized.class)
public class NextDateTest {

    public String expected;
    public String line;
    NextDate nextDate = new NextDate();
    public NextDateTest(String expected,String line){
        this.expected = expected;
        this.line = line;
    }

    @Parameterized.Parameters
    public static Collection<String[]> date(){
        return Arrays.asList(new String[][]{
                {"1964年9月1日","1964年8月31日"},//天数等于31
                {"日期输入错误","1964年8月32日"},//天数超出31
                {"1964年8月17日","1964年8月16日"},//天数没有超出31
                {"1964年12月9日","1964年12月8日"},//月份等于12，但天数不等于31
                {"1965年1月1日","1964年12月31日"},//月份等于12，且天数等于31
                {"日期输入错误","1964年13月30日"},//月份大于12
                {"日期输入错误","2050年12月31日"},//年份大于2050
                {"日期输入错误","1899年12月31日"},//年份小于1900
        });
    }

    @Test
    public void nextDate() {
        assertEquals(expected,nextDate.nextDate(line));
    }
}