package com.ctgu.zyj.work1;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.omg.CORBA.CODESET_INCOMPATIBLE;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.*;

@RunWith(Parameterized.class)
public class CommissionProblemTest {

    public String expected;
    public Integer[][] nums;

    public CommissionProblemTest(String expected,Integer[][] nums){
        this.expected = expected;
        this.nums = nums;
    }

    @Parameterized.Parameters
    public static Collection<Object[]> date() {
        return Arrays.asList(new Object[][]{
                {"佣金为：735.0美元",new Integer[][]{{5,20,30},{20,30,40}}},//一个月内走访两个城镇
                {"佣金为：359.0美元",new Integer[][]{{5,6,3},{4,8,10},{7,5,6},{9,5,7}}},//一个月内走访4个城镇
                {"输入数据不合理！",new Integer[][]{{0,20,30},{0,30,40}}},//月结枪机售出为0
                {"输入数据不合理！",new Integer[][]{{25,40,45},{40,50,60}}}//月结枪机售出量大于70个
        });
    }

    @Test
    public void sumCommission() {
        CommissionProblem commissionProblem = new CommissionProblem();
        assertEquals(expected,commissionProblem.sumCommission(nums));
    }
}